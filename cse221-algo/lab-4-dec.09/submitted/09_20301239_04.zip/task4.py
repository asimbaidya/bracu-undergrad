import heapq


def solve(G, s):

    dist = [-1] * len(G)
    vis = [0] * len(G)

    dist[s - 1] = 0

    q = []
    q.append((0, s))

    while len(q) != 0:
        heapq._heapify_max(q)
        _, u = q.pop(0)
        vis[u - 1] = True
        for wadj, adj in G[u]:
            if vis[adj - 1]:
                continue
            if dist[adj - 1] == -1:
                dist[adj - 1] = wadj
                q.append((dist[adj - 1], adj))
                continue
            alt = min(wadj, dist[u - 1])
            if alt > dist[adj - 1]:
                dist[adj - 1] = alt
                q.append((dist[adj - 1], adj))

    return dist


if __name__ == "__main__":
    data = ''
    with open('./input4.txt', 'r') as file:
        data = file.read()
        data = data.split('\n')

    out_file = open("./output4.txt", 'w')
    test = int(data.pop(0))
    for _ in range(test):
        device, link = map(int, data.pop(0).split())
        G = {}
        for i in range(1, device + 1):
            G[i] = []
        for _ in range(link):
            u, v, w = map(int, data.pop(0).split())
            G[u].append((w, v))
        s = int(data.pop(0))

        result = solve(G, s)
        # print(result)
        out_file.write(f"{' '.join(map(str, result))}\n")
    out_file.close()
