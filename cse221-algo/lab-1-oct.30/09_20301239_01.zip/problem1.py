# task 01 done
def task_one():
    # reading files
    file = open('p1_input.txt', 'r')
    data = file.readlines()
    file.close()

    # removing tailing \n
    data = [s[:-1] for s in data]

    odd_count = 0
    even_count = 0
    float_count = 0
    palindrome_count = 0
    non_palindrome_count = 0

    for pair in data:
        m1, m2 = '', ''
        num, word = pair.split()

        # parity checker
        if int(float(num)) != float(num):
            float_count += 1
            m1 = f'{num} cannot have parity'
        elif int(num) % 2 == 0:
            even_count += 1
            m1 = f'{num} has even parity'
        else:
            odd_count += 1
            m1 = f'{num} has odd parity'

        # palindrome checker
        if word == word[::-1]:
            palindrome_count += 1
            m2 = f'{word} is a palindrome'
        else:
            non_palindrome_count += 1
            m2 = f'{word} is a non-palindrome'

        print(m1, 'and', m2)

    # recording
    total_nums = odd_count + even_count + float_count
    total_words = palindrome_count + non_palindrome_count

    file = open('records.txt', 'w')

    r1 = f'Percentage of odd parity: {int(odd_count/total_nums*100)}%\n'
    r2 = f'Percentage of even parity: {int(even_count/total_nums*100)}%\n'
    r3 = f'Percentage of no parity: {int(float_count/total_nums*100)}%\n'
    r4 = f'Percentage of palindrome: {int(palindrome_count/total_words*100)}%\n'
    r5 = f'Percentage of non-palindrome: {int(non_palindrome_count/total_words*100)}%\n'

    # std/io
    print(r1, r2, r3, r4, r5, sep='', end='')

    # writing to the file
    file.writelines(r1)
    file.writelines(r2)
    file.writelines(r3)
    file.writelines(r4)
    file.writelines(r5)

    file.close()
    # EOT1


# task 02

if __name__ == "__main__":
    task_one()
