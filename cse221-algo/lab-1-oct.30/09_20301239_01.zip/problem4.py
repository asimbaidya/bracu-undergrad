# task 4 done


def multiply_matrix(a, b):
    """
    Complexity O (n^3)
    """
    n = len(a)

    c = [([0] * n) for _ in range(n)]

    for i in range(n):
        for j in range(n):
            for k in range(n):
                c[i][j] += a[i][k] * b[k][j]
    print(c)


if __name__ == "__main__":

    a = [
        [1, 2, 3],
        [4, 5, 6],
        [7, 8, 9],
    ]
    b = [
        [1, 2, 3],
        [4, 5, 6],
        [7, 8, 9],
    ]

    aa = [
        [1, 2],
        [3, 4],
    ]
    bb = [
        [5, 6],
        [7, 8],
    ]

    multiply_matrix(a, b)
