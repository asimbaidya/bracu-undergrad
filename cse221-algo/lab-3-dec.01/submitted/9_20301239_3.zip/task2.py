def BFS(G, src, trg, output):

    visited = [0] * (len(G) + 1)
    Q = []

    visited[int(src)] = True
    Q.append(src)

    while len(Q) > 0:
        m = Q.pop(0)
        # print(m, end=' ')
        output.append(m)
        if m == trg:
            break
        for adj in G[m]:
            if not visited[int(adj)]:
                visited[int(adj)] = True
                Q.append(adj)


def main():
    with open('./input.txt', 'r') as file:
        data = file.readlines()
        data = [s[:-1] for s in data]

    n = int(data[0])
    e = int(data[1])

    edges = []
    for e in data[2:]:
        edges.append(e.split())

    G = {}
    for i in range(1, n + 1):
        G[str(i)] = []
    for i, j in edges:
        G[i].append(j)

    output = []
    BFS(G, '1', '12', output)
    print(*output)

    with open('output2.txt', 'w') as file:
        for o in output:
            file.write(o + ' ')


if __name__ == "__main__":
    main()
