def main():
    with open('./input.txt', 'r') as file:
        data = file.readlines()
        data = [s[:-1] for s in data]

    n = int(data[0])
    e = int(data[1])

    edges = []
    for e in data[2:]:
        edges.append(e.split())

    G = {}
    for i in range(1, n + 1):
        G[str(i)] = []
    for i, j in edges:
        G[i].append(j)

    out = ''
    for node in G:
        out += f"{node}"
        for d in G[node]:
            out += f" {d}"
        out += '\n'
    print(out)

    with open('output1.txt', 'w') as file:
        file.write(out)


if __name__ == "__main__":
    main()
