-- (1)
select
  customer_name,
  loan.loan_number
from
  (
    (
      customer
      inner join borrower on customer.customer_id = borrower.customer_id
    )
    inner join loan on loan.loan_number = borrower.loan_number
  )
where
  branch_name = 'Downtown';

-- (2)
select
  c1.customer_name as Customer1,
  c2.customer_name as Customer2,
  c1.customer_city as City
from
  customer c1
  join customer c2 on c1.customer_city = c2.customer_city
  and c1.customer_name < c2.customer_name;

-- (3)
select
  branch_name as Branch_name,
  SUM(balance * 4 / 100) as Total_interest
from
  account
group by
  branch_name;

-- (4)
select
  d.account_number as Account_number,
  max(a.balance) as Highest_balance,
  c.customer_city as City
from
  (
    customer c
    inner join depositor d on c.customer_id = d.customer_id
  )
  inner join account a on d.account_number = a.account_number
group by
  c.customer_city;

-- (5)
select
  *
from
  (
    select
      l.loan_number,
      l.amount as loan_amount,
      c.customer_name
    from
      (
        borrower b
        inner join loan l on l.loan_number = b.loan_number
      )
      inner join customer c on b.customer_id = c.customer_id
    order by
      l.amount desc
    limit
      5
  ) as r
order by
  loan_amount asc,
  loan_number desc;

-- (6)
select
  c.customer_name
from
  (
    (
      loan l
      inner join account a on l.branch_name = a.branch_name
    )
    inner join borrower b on l.loan_number = b.loan_number
  )
  inner join customer c on b.customer_id = c.customer_id
where
  a.branch_name = "Perryridge"
  and l.branch_name = "Perryridge"
group by
  a.branch_name;

-- (7)
select
  c.customer_name,
  sum(l.amount) as total_loan
from
  (
    loan l
    inner join borrower b on l.loan_number = b.loan_number
  )
  inner join customer c on b.customer_id = c.customer_id
group by
  c.customer_id
having
  count(*) >= 2;
